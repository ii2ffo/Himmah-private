import 'package:flutter/material.dart';

import '../core/app_theme.dart';

class WorkoutsScreen extends StatelessWidget {
  const WorkoutsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final workouts = [
      ('Push Day', 'صدر · كتف · ترايسبس', '45 دقيقة', Icons.fitness_center),
      ('Pull Day', 'ظهر · بايسبس', '50 دقيقة', Icons.sports_gymnastics),
      ('Leg Day', 'أرجل · بطن', '55 دقيقة', Icons.directions_run),
    ];

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 120),
        children: [
          const Text('التمارين', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          const Text('خطة أسبوعية مرنة حسب هدفك', style: TextStyle(color: AppColors.muted)),
          const SizedBox(height: 18),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(color: AppColors.darkGreen, borderRadius: BorderRadius.circular(26)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('تمرين اليوم', style: TextStyle(color: Colors.white70)),
                const SizedBox(height: 6),
                const Text('Push Day', style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w900)),
                const SizedBox(height: 6),
                const Text('6 تمارين · 18 مجموعة', style: TextStyle(color: Colors.white70)),
                const SizedBox(height: 18),
                FilledButton.icon(
                  onPressed: () => _startWorkout(context),
                  icon: const Icon(Icons.play_arrow),
                  label: const Text('ابدأ التمرين'),
                  style: FilledButton.styleFrom(backgroundColor: AppColors.lime, foregroundColor: AppColors.darkGreen),
                ),
              ],
            ),
          ),
          const SizedBox(height: 22),
          const Text('الخطة الأسبوعية', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          for (final workout in workouts) ...[
            Card(
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                leading: CircleAvatar(backgroundColor: AppColors.primary.withValues(alpha: .1), child: Icon(workout.$4, color: AppColors.primary)),
                title: Text(workout.$1, style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text(workout.$2),
                trailing: Column(mainAxisAlignment: MainAxisAlignment.center, children: [const Icon(Icons.chevron_left), Text(workout.$3, style: const TextStyle(fontSize: 11, color: AppColors.muted))]),
              ),
            ),
            const SizedBox(height: 10),
          ],
        ],
      ),
    );
  }

  void _startWorkout(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('بدأ التمرين 💪'),
        content: const Text('تم تشغيل مؤقت التمرين التجريبي. المرحلة القادمة ستتضمن الجولات والأوزان والتكرارات.'),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('تمام'))],
      ),
    );
  }
}
