import 'package:flutter/material.dart';

import '../core/app_theme.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final items = [
      (Icons.person_outline, 'البيانات الشخصية'),
      (Icons.flag_outlined, 'الأهداف'),
      (Icons.notifications_none, 'الإشعارات'),
      (Icons.health_and_safety_outlined, 'ربط الصحة'),
      (Icons.language, 'اللغة'),
      (Icons.dark_mode_outlined, 'المظهر'),
      (Icons.help_outline, 'المساعدة والدعم'),
    ];

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 120),
        children: [
          const Text('حسابي', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
          const SizedBox(height: 18),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(18),
              child: Row(
                children: [
                  CircleAvatar(radius: 32, backgroundColor: AppColors.darkGreen, child: Icon(Icons.person, color: Colors.white, size: 34)),
                  SizedBox(width: 14),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('محمد الشمري', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)), SizedBox(height: 4), Text('خسارة وزن · نشاط مرتفع', style: TextStyle(color: AppColors.muted))])),
                  Icon(Icons.edit_outlined),
                ],
              ),
            ),
          ),
          const SizedBox(height: 18),
          Card(
            child: Column(
              children: [
                for (var i = 0; i < items.length; i++) ...[
                  ListTile(
                    leading: Icon(items[i].$1, color: AppColors.primary),
                    title: Text(items[i].$2, style: const TextStyle(fontWeight: FontWeight.w700)),
                    trailing: const Icon(Icons.chevron_left),
                    onTap: () {},
                  ),
                  if (i != items.length - 1) const Divider(height: 1, indent: 58),
                ],
              ],
            ),
          ),
          const SizedBox(height: 18),
          OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.logout), label: const Text('تسجيل الخروج')),
        ],
      ),
    );
  }
}
