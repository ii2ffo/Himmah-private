import 'package:flutter/material.dart';

import '../core/app_theme.dart';
import '../widgets/section_title.dart';
import '../widgets/stat_tile.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 120),
        children: [
          const _Header(),
          const SizedBox(height: 18),
          const _CalorieCard(),
          const SizedBox(height: 14),
          const Row(
            children: [
              StatTile(icon: Icons.directions_walk, label: 'الخطوات', value: '8,420', unit: 'خطوة'),
              SizedBox(width: 12),
              StatTile(icon: Icons.water_drop_outlined, label: 'الماء', value: '1.8', unit: 'لتر'),
            ],
          ),
          const SizedBox(height: 22),
          const SectionTitle(title: 'ملخص اليوم', action: 'عرض الكل'),
          const SizedBox(height: 10),
          const _TodaySummary(),
          const SizedBox(height: 22),
          const SectionTitle(title: 'هدف هذا الأسبوع'),
          const SizedBox(height: 10),
          const _WeeklyGoal(),
        ],
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header();

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        const CircleAvatar(
          radius: 24,
          backgroundColor: AppColors.darkGreen,
          child: Icon(Icons.person, color: Colors.white),
        ),
        const SizedBox(width: 12),
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('مرحباً محمد 👋', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800)),
              SizedBox(height: 3),
              Text('جاهز تبدأ يومك بقوة؟', style: TextStyle(color: AppColors.muted)),
            ],
          ),
        ),
        IconButton.filledTonal(onPressed: () {}, icon: const Icon(Icons.notifications_none)),
      ],
    );
  }
}

class _CalorieCard extends StatelessWidget {
  const _CalorieCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: const LinearGradient(
          colors: [AppColors.darkGreen, Color(0xFF0C5C3C)],
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              const Expanded(child: Text('السعرات اليومية', style: TextStyle(color: Colors.white70, fontSize: 16))),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(20)),
                child: const Text('78%', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
              ),
            ],
          ),
          const SizedBox(height: 12),
          const Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _CalorieMetric(label: 'المتبقي', value: '487'),
              _CalorieMetric(label: 'المستهلك', value: '1713', large: true),
              _CalorieMetric(label: 'المحروق', value: '520'),
            ],
          ),
          const SizedBox(height: 18),
          ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: const LinearProgressIndicator(
              value: 0.78,
              minHeight: 10,
              backgroundColor: Colors.white24,
              valueColor: AlwaysStoppedAnimation(AppColors.lime),
            ),
          ),
          const SizedBox(height: 16),
          const Row(
            children: [
              Expanded(child: _Macro(label: 'بروتين', value: '125 / 160 جم', progress: .78)),
              SizedBox(width: 12),
              Expanded(child: _Macro(label: 'كارب', value: '180 / 250 جم', progress: .72)),
              SizedBox(width: 12),
              Expanded(child: _Macro(label: 'دهون', value: '45 / 70 جم', progress: .64)),
            ],
          ),
        ],
      ),
    );
  }
}

class _CalorieMetric extends StatelessWidget {
  const _CalorieMetric({required this.label, required this.value, this.large = false});
  final String label;
  final String value;
  final bool large;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(value, style: TextStyle(color: Colors.white, fontSize: large ? 34 : 21, fontWeight: FontWeight.w900)),
        Text(label, style: const TextStyle(color: Colors.white70)),
      ],
    );
  }
}

class _Macro extends StatelessWidget {
  const _Macro({required this.label, required this.value, required this.progress});
  final String label;
  final String value;
  final double progress;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
        const SizedBox(height: 5),
        Text(value, style: const TextStyle(color: Colors.white70, fontSize: 11)),
        const SizedBox(height: 7),
        LinearProgressIndicator(value: progress, minHeight: 5, backgroundColor: Colors.white24, color: AppColors.lime),
      ],
    );
  }
}

class _TodaySummary extends StatelessWidget {
  const _TodaySummary();

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          children: [
            _SummaryRow(icon: Icons.restaurant, title: 'التغذية', subtitle: '3 وجبات مسجلة', trailing: '1713 سعرة'),
            Divider(height: 28, color: AppColors.border),
            _SummaryRow(icon: Icons.fitness_center, title: 'التمرين', subtitle: 'Push day', trailing: '45 دقيقة'),
            Divider(height: 28, color: AppColors.border),
            _SummaryRow(icon: Icons.bedtime_outlined, title: 'النوم', subtitle: 'آخر ليلة', trailing: '7 س 30 د'),
          ],
        ),
      ),
    );
  }
}

class _SummaryRow extends StatelessWidget {
  const _SummaryRow({required this.icon, required this.title, required this.subtitle, required this.trailing});
  final IconData icon;
  final String title;
  final String subtitle;
  final String trailing;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        CircleAvatar(backgroundColor: AppColors.primary.withValues(alpha: .1), child: Icon(icon, color: AppColors.primary)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w700)), Text(subtitle, style: const TextStyle(color: AppColors.muted, fontSize: 12))])),
        Text(trailing, style: const TextStyle(fontWeight: FontWeight.w700)),
      ],
    );
  }
}

class _WeeklyGoal extends StatelessWidget {
  const _WeeklyGoal();

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('نزول 0.5 كجم', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            const Text('استمر على متوسط عجز 500 سعرة يومياً', style: TextStyle(color: AppColors.muted)),
            const SizedBox(height: 14),
            const LinearProgressIndicator(value: .62, minHeight: 9, borderRadius: BorderRadius.all(Radius.circular(20))),
            const SizedBox(height: 8),
            const Text('تم إنجاز 62% من الهدف', style: TextStyle(color: AppColors.primary, fontWeight: FontWeight.w700)),
          ],
        ),
      ),
    );
  }
}
