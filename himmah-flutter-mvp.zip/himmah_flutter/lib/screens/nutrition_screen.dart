import 'package:flutter/material.dart';

import '../core/app_theme.dart';
import '../models/meal.dart';

class NutritionScreen extends StatefulWidget {
  const NutritionScreen({super.key});

  @override
  State<NutritionScreen> createState() => _NutritionScreenState();
}

class _NutritionScreenState extends State<NutritionScreen> {
  final meals = <Meal>[
    const Meal(name: 'بيض وخبز تنور', subtitle: 'الفطور · 8:20 ص', calories: 520, emoji: '🍳'),
    const Meal(name: 'دجاج ورز وسلطة', subtitle: 'الغداء · 2:45 م', calories: 710, emoji: '🍗'),
    const Meal(name: 'حليب عالي البروتين', subtitle: 'وجبة خفيفة · 7:10 م', calories: 210, emoji: '🥛'),
  ];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 120),
        children: [
          const Text('التغذية', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          const Text('سجّل أكلك وتابع احتياجك اليومي', style: TextStyle(color: AppColors.muted)),
          const SizedBox(height: 18),
          const _NutritionSummary(),
          const SizedBox(height: 18),
          TextField(
            decoration: InputDecoration(
              hintText: 'ابحث عن وجبة أو صنف...',
              prefixIcon: const Icon(Icons.search),
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
            ),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              const Expanded(child: Text('وجبات اليوم', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800))),
              TextButton.icon(onPressed: _addMeal, icon: const Icon(Icons.add), label: const Text('إضافة وجبة')),
            ],
          ),
          const SizedBox(height: 8),
          for (final meal in meals) ...[
            _MealTile(meal: meal),
            const SizedBox(height: 10),
          ],
        ],
      ),
    );
  }

  void _addMeal() {
    setState(() {
      meals.add(const Meal(name: 'وجبة جديدة', subtitle: 'تمت الإضافة الآن', calories: 320, emoji: '🥗'));
    });
  }
}

class _NutritionSummary extends StatelessWidget {
  const _NutritionSummary();

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          children: [
            const Row(
              children: [
                Expanded(child: _NutritionNumber(label: 'المستهلك', value: '1713')),
                Expanded(child: _NutritionNumber(label: 'الهدف', value: '2200')),
                Expanded(child: _NutritionNumber(label: 'المتبقي', value: '487')),
              ],
            ),
            const SizedBox(height: 16),
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: const LinearProgressIndicator(value: .78, minHeight: 11),
            ),
          ],
        ),
      ),
    );
  }
}

class _NutritionNumber extends StatelessWidget {
  const _NutritionNumber({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Column(children: [Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)), Text(label, style: const TextStyle(color: AppColors.muted))]);
  }
}

class _MealTile extends StatelessWidget {
  const _MealTile({required this.meal});
  final Meal meal;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: CircleAvatar(radius: 25, backgroundColor: AppColors.background, child: Text(meal.emoji, style: const TextStyle(fontSize: 23))),
        title: Text(meal.name, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text(meal.subtitle),
        trailing: Text('${meal.calories}\nسعرة', textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.primary)),
      ),
    );
  }
}
