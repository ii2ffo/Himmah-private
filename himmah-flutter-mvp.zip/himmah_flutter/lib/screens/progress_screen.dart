import 'package:flutter/material.dart';

import '../core/app_theme.dart';

class ProgressScreen extends StatelessWidget {
  const ProgressScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 120),
        children: const [
          Text('التقدم', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
          SizedBox(height: 4),
          Text('تابع وزنك ونتائجك بوضوح', style: TextStyle(color: AppColors.muted)),
          SizedBox(height: 18),
          _WeightCard(),
          SizedBox(height: 16),
          Row(
            children: [
              Expanded(child: _ProgressMetric(label: 'التغير', value: '-5.4 كجم')),
              SizedBox(width: 12),
              Expanded(child: _ProgressMetric(label: 'BMI', value: '28.6')),
              SizedBox(width: 12),
              Expanded(child: _ProgressMetric(label: 'دهون', value: '23%')),
            ],
          ),
          SizedBox(height: 20),
          _ChartCard(),
        ],
      ),
    );
  }
}

class _WeightCard extends StatelessWidget {
  const _WeightCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF0B5137), AppColors.darkGreen]),
        borderRadius: BorderRadius.circular(26),
      ),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('الوزن الحالي', style: TextStyle(color: Colors.white70)),
          SizedBox(height: 4),
          Row(crossAxisAlignment: CrossAxisAlignment.end, children: [Text('88.6', style: TextStyle(color: Colors.white, fontSize: 42, fontWeight: FontWeight.w900)), SizedBox(width: 6), Padding(padding: EdgeInsets.only(bottom: 7), child: Text('كجم', style: TextStyle(color: Colors.white70)))]),
          SizedBox(height: 10),
          Text('↓ 1.8 كجم خلال آخر 30 يوم', style: TextStyle(color: AppColors.lime, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}

class _ProgressMetric extends StatelessWidget {
  const _ProgressMetric({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(children: [Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)), const SizedBox(height: 4), Text(label, style: const TextStyle(color: AppColors.muted, fontSize: 12))])));
  }
}

class _ChartCard extends StatelessWidget {
  const _ChartCard();

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('اتجاه الوزن', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 20),
            SizedBox(
              height: 180,
              child: CustomPaint(painter: _LineChartPainter(), child: const SizedBox.expand()),
            ),
            const SizedBox(height: 8),
            const Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('يونيو', style: TextStyle(color: AppColors.muted)), Text('يوليو', style: TextStyle(color: AppColors.muted))]),
          ],
        ),
      ),
    );
  }
}

class _LineChartPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()..color = AppColors.border..strokeWidth = 1;
    for (var i = 1; i < 4; i++) {
      final y = size.height * i / 4;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
    final points = <Offset>[
      Offset(0, size.height * .18),
      Offset(size.width * .18, size.height * .26),
      Offset(size.width * .36, size.height * .33),
      Offset(size.width * .54, size.height * .49),
      Offset(size.width * .72, size.height * .58),
      Offset(size.width, size.height * .74),
    ];
    final path = Path()..moveTo(points.first.dx, points.first.dy);
    for (final p in points.skip(1)) {
      path.lineTo(p.dx, p.dy);
    }
    canvas.drawPath(path, Paint()..color = AppColors.primary..strokeWidth = 4..style = PaintingStyle.stroke..strokeCap = StrokeCap.round);
    for (final p in points) {
      canvas.drawCircle(p, 5, Paint()..color = AppColors.primary);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
