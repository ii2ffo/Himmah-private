import React, { useMemo, useState } from 'react';
import {
  Alert,
  I18nManager,
  Pressable,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

I18nManager.allowRTL(true);

type Tab = 'home' | 'food' | 'add' | 'workout' | 'profile';

type IconName = React.ComponentProps<typeof Ionicons>['name'];

const colors = {
  green900: '#052E25',
  green800: '#064A39',
  green700: '#08734B',
  green600: '#149447',
  green100: '#E8F6ED',
  lime: '#A8CF45',
  white: '#FFFFFF',
  bg: '#F5F7F5',
  text: '#12211C',
  muted: '#6D7C75',
  line: '#E5EAE7',
  orange: '#F3A938',
  blue: '#4C91E5',
  red: '#E85E5E',
};

const foodRows = [
  { title: 'فطور', subtitle: 'بيض، خبز تنور، شاي بالحليب', calories: 530, icon: 'sunny-outline' as IconName },
  { title: 'غداء', subtitle: 'صدر دجاج وأرز وسلطة', calories: 610, icon: 'restaurant-outline' as IconName },
  { title: 'وجبة خفيفة', subtitle: 'حليب عالي البروتين', calories: 180, icon: 'cafe-outline' as IconName },
];

const exercises = [
  ['ضغط صدر بالبار', '4 × 10', 'barbell-outline'],
  ['سحب علوي', '4 × 12', 'fitness-outline'],
  ['ضغط كتف دمبل', '3 × 10', 'body-outline'],
  ['تمرين بايسبس', '3 × 12', 'accessibility-outline'],
] as const;

function Ring({ value, total, label }: { value: number; total: number; label: string }) {
  const pct = Math.min(100, Math.round((value / total) * 100));
  return (
    <View style={styles.ringOuter}>
      <View style={styles.ringInner}>
        <Text style={styles.ringValue}>{value}</Text>
        <Text style={styles.ringLabel}>{label}</Text>
        <Text style={styles.ringPct}>{pct}%</Text>
      </View>
    </View>
  );
}

function MetricCard({ icon, value, label, tint = colors.green600 }: { icon: IconName; value: string; label: string; tint?: string }) {
  return (
    <View style={styles.metricCard}>
      <View style={[styles.metricIcon, { backgroundColor: `${tint}18` }]}>
        <Ionicons name={icon} size={20} color={tint} />
      </View>
      <Text style={styles.metricValue}>{value}</Text>
      <Text style={styles.metricLabel}>{label}</Text>
    </View>
  );
}

function SectionTitle({ title, action }: { title: string; action?: string }) {
  return (
    <View style={styles.sectionHeader}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {action ? <Text style={styles.sectionAction}>{action}</Text> : null}
    </View>
  );
}

function HomeScreen({ onNavigate }: { onNavigate: (tab: Tab) => void }) {
  return (
    <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
      <View style={styles.heroHeader}>
        <View>
          <Text style={styles.greeting}>مرحباً محمد 👋</Text>
          <Text style={styles.subGreeting}>جاهز تكمل تقدمك اليوم؟</Text>
        </View>
        <View style={styles.avatar}><Text style={styles.avatarText}>م</Text></View>
      </View>

      <View style={styles.calorieCard}>
        <View style={styles.calorieTop}>
          <Ring value={1713} total={2200} label="سعرة" />
          <View style={styles.calorieCopy}>
            <Text style={styles.calorieTitle}>هدف السعرات اليومي</Text>
            <Text style={styles.calorieRemaining}>متبقي 487 سعرة</Text>
            <View style={styles.progressTrack}><View style={[styles.progressFill, { width: '78%' }]} /></View>
          </View>
        </View>
        <View style={styles.macroRow}>
          <View><Text style={styles.macroValue}>125 / 160</Text><Text style={styles.macroLabel}>بروتين</Text></View>
          <View><Text style={styles.macroValue}>180 / 220</Text><Text style={styles.macroLabel}>كارب</Text></View>
          <View><Text style={styles.macroValue}>49 / 70</Text><Text style={styles.macroLabel}>دهون</Text></View>
        </View>
      </View>

      <View style={styles.metricsGrid}>
        <MetricCard icon="water-outline" value="6 أكواب" label="الماء" tint={colors.blue} />
        <MetricCard icon="footsteps-outline" value="10,842" label="الخطوات" tint={colors.orange} />
        <MetricCard icon="barbell-outline" value="45 دقيقة" label="التمرين" />
      </View>

      <SectionTitle title="هدف اليوم" />
      <View style={styles.goalCard}>
        <View style={styles.goalIcon}><Ionicons name="locate-outline" size={28} color={colors.green600} /></View>
        <View style={{ flex: 1 }}>
          <Text style={styles.goalTitle}>أنت على الطريق الصحيح</Text>
          <Text style={styles.goalSubtitle}>أكمل 1,158 خطوة للوصول لهدفك اليومي</Text>
          <View style={styles.progressTrack}><View style={[styles.progressFill, { width: '90%' }]} /></View>
        </View>
      </View>

      <SectionTitle title="آخر الوجبات" action="عرض الكل" />
      {foodRows.slice(0, 2).map((item) => (
        <Pressable key={item.title} style={styles.listCard} onPress={() => onNavigate('food')}>
          <View style={styles.listIcon}><Ionicons name={item.icon} size={22} color={colors.green600} /></View>
          <View style={{ flex: 1 }}><Text style={styles.listTitle}>{item.title}</Text><Text style={styles.listSubtitle}>{item.subtitle}</Text></View>
          <Text style={styles.listCalories}>{item.calories} سعرة</Text>
        </Pressable>
      ))}
    </ScrollView>
  );
}

function FoodScreen() {
  const [extra, setExtra] = useState(0);
  const total = foodRows.reduce((sum, item) => sum + item.calories, 0) + extra;
  return (
    <ScrollView contentContainerStyle={styles.scroll}>
      <Text style={styles.pageTitle}>التغذية</Text>
      <Text style={styles.pageSubtitle}>سجل وجباتك وراقب احتياجك اليومي</Text>
      <View style={styles.summaryCard}>
        <Text style={styles.summarySmall}>المستهلك اليوم</Text>
        <Text style={styles.summaryBig}>{total}</Text>
        <Text style={styles.summarySmall}>من 2200 سعرة</Text>
        <View style={styles.progressTrack}><View style={[styles.progressFill, { width: `${Math.min(100, (total / 2200) * 100)}%` }]} /></View>
      </View>
      <SectionTitle title="وجبات اليوم" />
      {foodRows.map((item) => (
        <View key={item.title} style={styles.listCard}>
          <View style={styles.listIcon}><Ionicons name={item.icon} size={22} color={colors.green600} /></View>
          <View style={{ flex: 1 }}><Text style={styles.listTitle}>{item.title}</Text><Text style={styles.listSubtitle}>{item.subtitle}</Text></View>
          <Text style={styles.listCalories}>{item.calories} سعرة</Text>
        </View>
      ))}
      {extra > 0 && (
        <View style={styles.listCard}>
          <View style={styles.listIcon}><Ionicons name="nutrition-outline" size={22} color={colors.green600} /></View>
          <View style={{ flex: 1 }}><Text style={styles.listTitle}>وجبة مضافة</Text><Text style={styles.listSubtitle}>وجبة تجريبية</Text></View>
          <Text style={styles.listCalories}>{extra} سعرة</Text>
        </View>
      )}
      <Pressable style={styles.primaryButton} onPress={() => setExtra((v) => (v ? 0 : 320))}>
        <Ionicons name={extra ? 'trash-outline' : 'add-circle-outline'} size={20} color={colors.white} />
        <Text style={styles.primaryButtonText}>{extra ? 'حذف الوجبة التجريبية' : 'إضافة وجبة تجريبية'}</Text>
      </Pressable>
    </ScrollView>
  );
}

function WorkoutScreen() {
  const [started, setStarted] = useState(false);
  return (
    <ScrollView contentContainerStyle={styles.scroll}>
      <Text style={styles.pageTitle}>التمارين</Text>
      <Text style={styles.pageSubtitle}>خطة اليوم: الجزء العلوي</Text>
      <View style={styles.workoutHero}>
        <View style={{ flex: 1 }}>
          <Text style={styles.workoutHeroLabel}>تمرين اليوم</Text>
          <Text style={styles.workoutHeroTitle}>Upper Body</Text>
          <Text style={styles.workoutHeroSub}>4 تمارين • 50 دقيقة</Text>
        </View>
        <Ionicons name="barbell" size={58} color={colors.lime} />
      </View>
      <SectionTitle title="تفاصيل التمرين" />
      {exercises.map(([title, reps, icon], i) => (
        <View key={title} style={styles.exerciseCard}>
          <View style={styles.exerciseIndex}><Text style={styles.exerciseIndexText}>{i + 1}</Text></View>
          <View style={{ flex: 1 }}><Text style={styles.listTitle}>{title}</Text><Text style={styles.listSubtitle}>{reps}</Text></View>
          <Ionicons name={icon as IconName} size={24} color={colors.green600} />
        </View>
      ))}
      <Pressable style={[styles.primaryButton, started && styles.secondaryButton]} onPress={() => setStarted(!started)}>
        <Ionicons name={started ? 'pause' : 'play'} size={20} color={started ? colors.green700 : colors.white} />
        <Text style={[styles.primaryButtonText, started && { color: colors.green700 }]}>{started ? 'إيقاف التمرين مؤقتاً' : 'ابدأ التمرين'}</Text>
      </Pressable>
    </ScrollView>
  );
}

function AddScreen({ onNavigate }: { onNavigate: (tab: Tab) => void }) {
  const actions: { title: string; subtitle: string; icon: IconName; target: Tab }[] = [
    { title: 'إضافة وجبة', subtitle: 'سجل السعرات والماكروز', icon: 'restaurant-outline', target: 'food' },
    { title: 'إضافة تمرين', subtitle: 'سجل جلسة مقاومة أو كارديو', icon: 'barbell-outline', target: 'workout' },
    { title: 'تسجيل وزن', subtitle: 'حدّث قياس وزنك الحالي', icon: 'scale-outline', target: 'profile' },
    { title: 'إضافة ماء', subtitle: 'أضف كوباً إلى استهلاكك', icon: 'water-outline', target: 'home' },
  ];
  return (
    <ScrollView contentContainerStyle={styles.scroll}>
      <Text style={styles.pageTitle}>إضافة سريعة</Text>
      <Text style={styles.pageSubtitle}>وش تبي تسجل الآن؟</Text>
      {actions.map((item) => (
        <Pressable key={item.title} style={styles.quickAction} onPress={() => onNavigate(item.target)}>
          <View style={styles.quickActionIcon}><Ionicons name={item.icon} size={28} color={colors.white} /></View>
          <View style={{ flex: 1 }}><Text style={styles.quickActionTitle}>{item.title}</Text><Text style={styles.listSubtitle}>{item.subtitle}</Text></View>
          <Ionicons name="chevron-back" size={22} color={colors.muted} />
        </Pressable>
      ))}
    </ScrollView>
  );
}

function ProfileScreen() {
  const chart = useMemo(() => [88.9, 88.4, 88.1, 87.6, 87.2, 86.9, 86.4], []);
  return (
    <ScrollView contentContainerStyle={styles.scroll}>
      <View style={styles.profileHeader}>
        <View style={styles.profileAvatar}><Text style={styles.profileAvatarText}>م</Text></View>
        <Text style={styles.profileName}>محمد الشمري</Text>
        <Text style={styles.pageSubtitle}>هدفك الحالي: خسارة الدهون</Text>
      </View>
      <View style={styles.weightCard}>
        <Text style={styles.summarySmall}>الوزن الحالي</Text>
        <Text style={styles.weightValue}>86.4 <Text style={styles.weightUnit}>كجم</Text></Text>
        <Text style={styles.weightLoss}>↓ 2.5 كجم خلال 30 يوم</Text>
        <View style={styles.chartRow}>
          {chart.map((v, i) => <View key={i} style={[styles.chartBar, { height: 22 + (89 - v) * 13 }]} />)}
        </View>
      </View>
      <SectionTitle title="الحساب والإعدادات" />
      {[
        ['person-outline', 'البيانات الشخصية'],
        ['notifications-outline', 'التذكيرات والإشعارات'],
        ['heart-outline', 'ربط Apple Health'],
        ['shield-checkmark-outline', 'الخصوصية والأمان'],
        ['help-circle-outline', 'المساعدة والدعم'],
      ].map(([icon, title]) => (
        <Pressable key={title} style={styles.settingsRow} onPress={() => Alert.alert(title, 'هذه الميزة جاهزة للربط في المرحلة التالية.') }>
          <View style={styles.settingsLeft}><Ionicons name={icon as IconName} size={22} color={colors.green600} /><Text style={styles.settingsText}>{title}</Text></View>
          <Ionicons name="chevron-back" size={20} color={colors.muted} />
        </Pressable>
      ))}
    </ScrollView>
  );
}

export default function App() {
  const [tab, setTab] = useState<Tab>('home');
  const screen = {
    home: <HomeScreen onNavigate={setTab} />,
    food: <FoodScreen />,
    add: <AddScreen onNavigate={setTab} />,
    workout: <WorkoutScreen />,
    profile: <ProfileScreen />,
  }[tab];
  const tabs: { key: Tab; label: string; icon: IconName }[] = [
    { key: 'home', label: 'الرئيسية', icon: 'home-outline' },
    { key: 'food', label: 'التغذية', icon: 'restaurant-outline' },
    { key: 'add', label: 'إضافة', icon: 'add' },
    { key: 'workout', label: 'التمارين', icon: 'barbell-outline' },
    { key: 'profile', label: 'حسابي', icon: 'person-outline' },
  ];
  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="dark-content" />
      <View style={styles.screen}>{screen}</View>
      <View style={styles.tabBar}>
        {tabs.map((item) => {
          const active = item.key === tab;
          const isAdd = item.key === 'add';
          return (
            <Pressable key={item.key} style={styles.tabItem} onPress={() => setTab(item.key)}>
              <View style={isAdd ? styles.addTab : undefined}>
                <Ionicons name={item.icon} size={isAdd ? 28 : 22} color={isAdd ? colors.white : active ? colors.green600 : colors.muted} />
              </View>
              {!isAdd && <Text style={[styles.tabLabel, active && styles.tabLabelActive]}>{item.label}</Text>}
            </Pressable>
          );
        })}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  screen: { flex: 1 },
  scroll: { padding: 20, paddingBottom: 36 },
  heroHeader: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  greeting: { fontSize: 23, fontWeight: '800', color: colors.text, textAlign: 'right' },
  subGreeting: { color: colors.muted, fontSize: 14, marginTop: 4, textAlign: 'right' },
  avatar: { width: 46, height: 46, borderRadius: 23, backgroundColor: colors.green100, alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontWeight: '900', color: colors.green700, fontSize: 18 },
  calorieCard: { backgroundColor: colors.green900, borderRadius: 24, padding: 20 },
  calorieTop: { flexDirection: 'row-reverse', alignItems: 'center', gap: 18 },
  ringOuter: { width: 118, height: 118, borderRadius: 59, borderWidth: 9, borderColor: colors.lime, alignItems: 'center', justifyContent: 'center' },
  ringInner: { width: 88, height: 88, borderRadius: 44, backgroundColor: colors.green800, alignItems: 'center', justifyContent: 'center' },
  ringValue: { color: colors.white, fontSize: 27, fontWeight: '900' },
  ringLabel: { color: '#CDE2D9', fontSize: 12 },
  ringPct: { color: colors.lime, fontSize: 12, fontWeight: '700' },
  calorieCopy: { flex: 1 },
  calorieTitle: { color: colors.white, fontSize: 17, fontWeight: '800', textAlign: 'right' },
  calorieRemaining: { color: colors.lime, fontSize: 14, marginVertical: 9, textAlign: 'right' },
  progressTrack: { height: 8, backgroundColor: '#DDE6E1', borderRadius: 5, overflow: 'hidden', marginTop: 10 },
  progressFill: { height: '100%', backgroundColor: colors.green600, borderRadius: 5 },
  macroRow: { flexDirection: 'row-reverse', justifyContent: 'space-around', marginTop: 20, paddingTop: 16, borderTopWidth: 1, borderTopColor: '#1A5B49' },
  macroValue: { color: colors.white, fontWeight: '800', textAlign: 'center' },
  macroLabel: { color: '#AFC9BF', fontSize: 12, textAlign: 'center', marginTop: 3 },
  metricsGrid: { flexDirection: 'row-reverse', gap: 10, marginTop: 14 },
  metricCard: { flex: 1, backgroundColor: colors.white, borderRadius: 18, padding: 14, alignItems: 'center', borderWidth: 1, borderColor: colors.line },
  metricIcon: { width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center' },
  metricValue: { fontSize: 15, fontWeight: '900', color: colors.text, marginTop: 8 },
  metricLabel: { fontSize: 12, color: colors.muted, marginTop: 2 },
  sectionHeader: { flexDirection: 'row-reverse', justifyContent: 'space-between', marginTop: 24, marginBottom: 12 },
  sectionTitle: { fontSize: 18, fontWeight: '900', color: colors.text },
  sectionAction: { color: colors.green600, fontWeight: '700' },
  goalCard: { backgroundColor: colors.white, borderRadius: 20, padding: 16, flexDirection: 'row-reverse', alignItems: 'center', gap: 14, borderWidth: 1, borderColor: colors.line },
  goalIcon: { width: 54, height: 54, borderRadius: 17, backgroundColor: colors.green100, alignItems: 'center', justifyContent: 'center' },
  goalTitle: { fontWeight: '900', color: colors.text, textAlign: 'right' },
  goalSubtitle: { fontSize: 12, color: colors.muted, marginTop: 5, textAlign: 'right' },
  listCard: { backgroundColor: colors.white, borderRadius: 17, padding: 14, flexDirection: 'row-reverse', alignItems: 'center', gap: 12, marginBottom: 10, borderWidth: 1, borderColor: colors.line },
  listIcon: { width: 44, height: 44, borderRadius: 14, backgroundColor: colors.green100, alignItems: 'center', justifyContent: 'center' },
  listTitle: { color: colors.text, fontWeight: '800', fontSize: 15, textAlign: 'right' },
  listSubtitle: { color: colors.muted, fontSize: 12, marginTop: 4, textAlign: 'right' },
  listCalories: { color: colors.green700, fontWeight: '800', fontSize: 13 },
  pageTitle: { color: colors.text, fontSize: 28, fontWeight: '900', textAlign: 'right', marginTop: 8 },
  pageSubtitle: { color: colors.muted, fontSize: 14, textAlign: 'right', marginTop: 5, marginBottom: 18 },
  summaryCard: { backgroundColor: colors.white, borderRadius: 22, padding: 20, alignItems: 'center', borderWidth: 1, borderColor: colors.line },
  summarySmall: { color: colors.muted, fontSize: 13 },
  summaryBig: { color: colors.green700, fontWeight: '900', fontSize: 42, marginVertical: 3 },
  primaryButton: { backgroundColor: colors.green600, borderRadius: 16, minHeight: 54, alignItems: 'center', justifyContent: 'center', flexDirection: 'row-reverse', gap: 8, marginTop: 18 },
  primaryButtonText: { color: colors.white, fontWeight: '900', fontSize: 15 },
  secondaryButton: { backgroundColor: colors.green100, borderWidth: 1, borderColor: colors.green600 },
  workoutHero: { backgroundColor: colors.green900, borderRadius: 24, padding: 22, flexDirection: 'row-reverse', alignItems: 'center' },
  workoutHeroLabel: { color: '#BBD3C9', textAlign: 'right' },
  workoutHeroTitle: { color: colors.white, fontSize: 27, fontWeight: '900', textAlign: 'right', marginVertical: 6 },
  workoutHeroSub: { color: colors.lime, textAlign: 'right' },
  exerciseCard: { backgroundColor: colors.white, borderRadius: 17, padding: 14, flexDirection: 'row-reverse', alignItems: 'center', gap: 12, marginBottom: 10, borderWidth: 1, borderColor: colors.line },
  exerciseIndex: { width: 36, height: 36, borderRadius: 18, backgroundColor: colors.green100, alignItems: 'center', justifyContent: 'center' },
  exerciseIndexText: { color: colors.green700, fontWeight: '900' },
  quickAction: { backgroundColor: colors.white, borderRadius: 20, padding: 16, flexDirection: 'row-reverse', alignItems: 'center', gap: 14, marginBottom: 12, borderWidth: 1, borderColor: colors.line },
  quickActionIcon: { width: 54, height: 54, borderRadius: 18, backgroundColor: colors.green600, alignItems: 'center', justifyContent: 'center' },
  quickActionTitle: { fontSize: 17, color: colors.text, fontWeight: '900', textAlign: 'right' },
  profileHeader: { alignItems: 'center', marginTop: 10 },
  profileAvatar: { width: 86, height: 86, borderRadius: 43, backgroundColor: colors.green900, alignItems: 'center', justifyContent: 'center' },
  profileAvatarText: { color: colors.lime, fontWeight: '900', fontSize: 32 },
  profileName: { fontSize: 22, fontWeight: '900', color: colors.text, marginTop: 12 },
  weightCard: { backgroundColor: colors.white, borderRadius: 22, padding: 20, alignItems: 'center', borderWidth: 1, borderColor: colors.line },
  weightValue: { color: colors.text, fontSize: 40, fontWeight: '900', marginTop: 4 },
  weightUnit: { fontSize: 16, color: colors.muted },
  weightLoss: { color: colors.green600, fontWeight: '800', marginTop: 4 },
  chartRow: { width: '100%', height: 80, marginTop: 20, flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between' },
  chartBar: { width: 25, backgroundColor: colors.green600, borderRadius: 7 },
  settingsRow: { backgroundColor: colors.white, borderRadius: 15, padding: 16, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', marginBottom: 9, borderWidth: 1, borderColor: colors.line },
  settingsLeft: { flexDirection: 'row-reverse', alignItems: 'center', gap: 12 },
  settingsText: { color: colors.text, fontWeight: '700' },
  tabBar: { height: 74, backgroundColor: colors.white, borderTopWidth: 1, borderTopColor: colors.line, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-around', paddingBottom: 6 },
  tabItem: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  tabLabel: { color: colors.muted, fontSize: 11, marginTop: 4 },
  tabLabelActive: { color: colors.green600, fontWeight: '900' },
  addTab: { width: 50, height: 50, borderRadius: 25, backgroundColor: colors.green600, alignItems: 'center', justifyContent: 'center', marginTop: -28, borderWidth: 4, borderColor: colors.white },
});
